package test_paper;

import java.util.Scanner;

public class CollegeStaffManager {
    private static Staff[] staffArray = new Staff[10];
    private static int count = 0;
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n===== College Staff Management Menu =====");
            System.out.println("1. Add Teaching Staff :");
            System.out.println("2. Add Lab Staff :");
            System.out.println("3. Display All Teaching Staff :");
            System.out.println("4. Display All Lab Staff");
            System.out.println("5. Find Specific Teaching Staff :");
            System.out.println("6. Find Specific Lab Staff :");
            System.out.println("7. Display Teaching Staff Who Worked Highest Hours :");
            System.out.println("8. Display Teaching Staff With Lowest Salary");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1 : addTeachingStaff();
                case 2 : addLabStaff();
                case 3 : displayTeachingStaff();
                case 4 : displayLabStaff();
                case 5 :findTeachingStaff();
                case 6 : findLabStaff();
                case 7 : displayTeachingStaffWithMaxHours();
                case 8 : displayTeachingStaffWithMinSalary();
                case 9 : System.out.println("Exiting");
                default : System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 9);
    }

    private static void addTeachingStaff() {
      
            System.out.print("Enter ID: ");
            int id = sc.nextInt();
            sc.nextLine(); 

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter No. of Hours: ");
            int hours = sc.nextInt();

            System.out.print("Enter Charges per Hour: ");
            int charges = sc.nextInt();

            TeachingStaff ts = new TeachingStaff(id, name, hours, charges);
            staffArray[count++] = ts;

            System.out.println("Teaching staff added successfully.");
        } 
    
    

    private static void addLabStaff() {
       
            System.out.print("Enter ID: ");
            int id = sc.nextInt();
            sc.nextLine(); 

            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Salary: ");
            int salary = sc.nextInt();

            LabStaff ls = new LabStaff(id, name, salary);
            staffArray[count++] = ls;

            System.out.println("Lab staff added successfully.");
        } 
    

    private static void displayTeachingStaff() {
       
        for (int i = 0; i < count; i++) {
           
                System.out.println(staffArray[i]);
                
            }
    }

    private static void displayLabStaff() {
       
        for (int i = 0; i < count; i++) {
           
                System.out.println(staffArray[i]);
                
                
        }
        
    }
    

    private static void findTeachingStaff() {
        System.out.print("Enter Teaching Staff ID to search: ");
        int id = sc.nextInt();
        for (int i = 0; i < count; i++) {
            if (staffArray[i] instanceof TeachingStaff && staffArray[i].getId() == id) {
                System.out.println("Found: " + staffArray[i]);
                return;
            }
        }
        System.out.println("Teaching staff not found.");
    }

    private static void findLabStaff() {
        System.out.print("Enter Lab Staff ID to search: ");
        int id = sc.nextInt();
        for (int i = 0; i < count; i++) {
            if (staffArray[i] instanceof LabStaff && staffArray[i].getId() == id) {
                System.out.println("Found: " + staffArray[i]);
                return;
            }
        }
        System.out.println("Lab staff not found.");
    }

    private static void displayTeachingStaffWithMaxHours() {
        TeachingStaff maxStaff = null;
        for (int i = 0; i < count; i++) {
            if (staffArray[i] instanceof TeachingStaff ts) {
             
            }
        }
        if (maxStaff != null) {
            System.out.println("Teaching staff with highest working hours:");
            System.out.println(maxStaff);
        } else {
            System.out.println("No teaching staff available.");
        }
    }

    private static void displayTeachingStaffWithMinSalary() {
        TeachingStaff minStaff = null;
        for (int i = 0; i < count; i++) {
            if (staffArray[i] instanceof TeachingStaff ts) {
        
            }
        }
        if (minStaff != null) {
            System.out.println("Teaching staff with lowest salary:");
            System.out.println(minStaff);
        } else {
            System.out.println("No teaching staff available.");
        }
    }

}