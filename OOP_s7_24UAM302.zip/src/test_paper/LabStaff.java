package test_paper;

public class LabStaff extends Staff {
    private int salary;

    public LabStaff(int id, String name, int salary)  {
        super(id, name);
        if (salary <= 0) {
            System.out.print("Salary must be greater than 0.");
        }
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Lab Staff [ID=" + id + ", Name=" + name + ", Salary=" + salary + "]";
    }
}
