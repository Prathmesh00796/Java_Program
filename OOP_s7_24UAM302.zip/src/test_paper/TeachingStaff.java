package test_paper;

public class TeachingStaff extends Staff {
    private int noOfHours;
    private int chargesPerHour;

    public TeachingStaff(int id, String name, int noOfHours, int chargesPerHour) {
        super(id, name);
        if (noOfHours <= 0 || chargesPerHour <= 0) {
           System.out.print("No of hours and charges per hour must be greater than 0.");
        }
        this.noOfHours = noOfHours;
        this.chargesPerHour = chargesPerHour;
    }

    public int getNoOfHours() {
        return noOfHours;
    }

    public int getChargesPerHour() {
        return chargesPerHour;
    }

    public int calculateSalary() {
        return noOfHours * chargesPerHour;
    }

    @Override
    public String toString() {
        return "Teaching Staff [ID=" + id + ", Name=" + name + ", Hours=" + noOfHours +
               ", Charges/Hour=" + chargesPerHour + ", Salary=" + calculateSalary() + "]";
    }
}
